# fourthstepwindow.py
import sys
import os
import pandas as pd
import numpy as np
import pyqtgraph as pg
from pyqtgraph.exporters import ImageExporter
from scipy.signal import savgol_filter
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPainter, QPixmap
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLineEdit,
    QLabel, QPushButton, QFileDialog, QMessageBox, QTabWidget
)

# --- BackgroundWidget ---
class BackgroundWidget(QWidget):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Φορτώνουμε το background image (υποθέτουμε ότι βρίσκεται στον ίδιο φάκελο)
        self.background_image = QPixmap("NGM--MONOCHROME-GRAY-33.png")
        
    def paintEvent(self, event):
        painter = QPainter(self)
        if not self.background_image.isNull():
            scaled = self.background_image.scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            x = (self.width() - scaled.width()) // 2
            y = (self.height() - scaled.height()) // 2
            painter.drawPixmap(x, y, scaled)
        super().paintEvent(event)

# --- FourthStepWindow ---
class FourthStepWindow(BackgroundWidget):
    def __init__(self, main_window=None):
        super().__init__()
        self.main_window = main_window
        self.setWindowTitle("Βήμα Τέταρτο")
        self.setMinimumSize(800, 600)
        
        # Δημιουργία QTabWidget για δύο επιλογές διαγράμματος
        self.tabs = QTabWidget()
        
        # Tab 1: BCJR Data Diagram
        self.tab1 = QWidget()
        self.tab1_layout = QVBoxLayout()
        self.tab1_file_label = QLabel("Χρησιμοποιείται αρχείο: BCJR_Output_clean.csv")
        self.tab1_layout.addWidget(self.tab1_file_label)
        self.tab1_plot = pg.PlotWidget()
        self.tab1_layout.addWidget(self.tab1_plot)
        tab1_btn_layout = QHBoxLayout()
        self.tab1_btn_raw = QPushButton("Raw")
        self.tab1_btn_rolling = QPushButton("Rolling Average")
        self.tab1_btn_savgol = QPushButton("Savitzky-Golay")
        tab1_btn_layout.addWidget(self.tab1_btn_raw)
        tab1_btn_layout.addWidget(self.tab1_btn_rolling)
        tab1_btn_layout.addWidget(self.tab1_btn_savgol)
        self.tab1_layout.addLayout(tab1_btn_layout)
        self.tab1.setLayout(self.tab1_layout)
        
        # Tab 2: Pressure-Based Diagram
        self.tab2 = QWidget()
        self.tab2_layout = QVBoxLayout()
        # Εισαγωγή sea-level τιμών: P₀ και T₀
        input_layout = QHBoxLayout()
        self.tab2_label_P0 = QLabel("P₀ (hPa):")
        self.tab2_edit_P0 = QLineEdit("1013.25")
        self.tab2_label_T0 = QLabel("T₀ (°C):")
        self.tab2_edit_T0 = QLineEdit("15")
        input_layout.addWidget(self.tab2_label_P0)
        input_layout.addWidget(self.tab2_edit_P0)
        input_layout.addWidget(self.tab2_label_T0)
        input_layout.addWidget(self.tab2_edit_T0)
        self.tab2_layout.addLayout(input_layout)
        self.tab2_plot = pg.PlotWidget()
        self.tab2_layout.addWidget(self.tab2_plot)
        tab2_btn_layout = QHBoxLayout()
        self.tab2_btn_raw = QPushButton("Raw")
        self.tab2_btn_rolling = QPushButton("Rolling Average")
        self.tab2_btn_savgol = QPushButton("Savitzky-Golay")
        tab2_btn_layout.addWidget(self.tab2_btn_raw)
        tab2_btn_layout.addWidget(self.tab2_btn_rolling)
        tab2_btn_layout.addWidget(self.tab2_btn_savgol)
        self.tab2_layout.addLayout(tab2_btn_layout)
        self.tab2.setLayout(self.tab2_layout)
        
        self.tabs.addTab(self.tab1, "BCJR Data")
        self.tabs.addTab(self.tab2, "Pressure-Based")
        
        # Κύρια διάταξη του FourthStepWindow
        self.main_layout = QVBoxLayout()
        self.main_layout.addWidget(self.tabs)
        self.save_btn = QPushButton("Αποθήκευση Γραφήματος")
        self.save_btn.clicked.connect(self.save_plot)
        self.main_layout.addWidget(self.save_btn)
        self.setLayout(self.main_layout)
        
        # Συνδέσεις κουμπιών για Tab 1
        self.tab1_btn_raw.clicked.connect(self.plot_tab1_raw)
        self.tab1_btn_rolling.clicked.connect(self.plot_tab1_rolling)
        self.tab1_btn_savgol.clicked.connect(self.plot_tab1_savgol)
        # Συνδέσεις για Tab 2
        self.tab2_btn_raw.clicked.connect(self.plot_tab2_raw)
        self.tab2_btn_rolling.clicked.connect(self.plot_tab2_rolling)
        self.tab2_btn_savgol.clicked.connect(self.plot_tab2_savgol)
        
        # Φόρτωση δεδομένων
        self.load_tab1_data()
        self.load_tab2_data()
        self.plot_tab1_raw()
        self.plot_tab2_raw()

    # --- Tab 1: BCJR Data Diagram ---
    def load_tab1_data(self):
        file_name = "BCJR_Output_clean.csv"
        if os.path.exists(file_name):
            self.df_tab1 = pd.read_csv(file_name)
        else:
            file_path, _ = QFileDialog.getOpenFileName(self, "Επιλογή CSV αρχείου για BCJR Data", "", "CSV Files (*.csv)")
            if not file_path:
                QMessageBox.critical(self, "Σφάλμα", "Δεν επιλέχθηκε αρχείο για BCJR Data.")
                return
            self.df_tab1 = pd.read_csv(file_path)
        # Δεδομένα για Tab 1:
        # Υψόμετρο: στήλη 9 (index 8)
        # Θερμοκρασία: στήλη 12 (index 11)
        if self.df_tab1.shape[1] < 12:
            QMessageBox.critical(self, "Σφάλμα", "Το αρχείο BCJR Data δεν περιέχει 12 στήλες.")
            return
        self.altitude_tab1 = self.df_tab1.iloc[:, 8]
        self.temperature_tab1 = self.df_tab1.iloc[:, 11]

    def plot_tab1_raw(self):
        self.tab1_plot.clear()
        self.tab1_plot.plot(self.altitude_tab1, self.temperature_tab1, pen='r', symbol='o', symbolSize=5, symbolBrush='b')
        self.tab1_plot.setLabel("left", "Θερμοκρασία (°C)")
        self.tab1_plot.setLabel("bottom", "Υψόμετρο (m)")
        self.tab1_plot.setTitle("BCJR Data (Raw)")

    def plot_tab1_rolling(self):
        self.tab1_plot.clear()
        alt_roll = self.altitude_tab1.rolling(window=11, center=True).mean()
        temp_roll = self.temperature_tab1.rolling(window=11, center=True).mean()
        self.tab1_plot.plot(alt_roll, temp_roll, pen='b', symbol='o', symbolSize=5, symbolBrush='b')
        self.tab1_plot.setLabel("left", "Θερμοκρασία (°C)")
        self.tab1_plot.setLabel("bottom", "Υψόμετρο (m)")
        self.tab1_plot.setTitle("BCJR Data (Rolling Average)")

    def plot_tab1_savgol(self):
        self.tab1_plot.clear()
        alt_savgol = savgol_filter(self.altitude_tab1, window_length=11, polyorder=2)
        temp_savgol = savgol_filter(self.temperature_tab1, window_length=11, polyorder=2)
        self.tab1_plot.plot(alt_savgol, temp_savgol, pen='g', symbol='o', symbolSize=5, symbolBrush='b')
        self.tab1_plot.setLabel("left", "Θερμοκρασία (°C)")
        self.tab1_plot.setLabel("bottom", "Υψόμετρο (m)")
        self.tab1_plot.setTitle("BCJR Data (Savitzky-Golay)")

    # --- Tab 2: Pressure-Based Diagram ---
    def load_tab2_data(self):
        file_name = "BCJR_Output_clean.csv"
        if os.path.exists(file_name):
            self.df_tab2 = pd.read_csv(file_name)
        else:
            file_path, _ = QFileDialog.getOpenFileName(self, "Επιλογή CSV αρχείου για Pressure-Based Data", "", "CSV Files (*.csv)")
            if not file_path:
                QMessageBox.critical(self, "Σφάλμα", "Δεν επιλέχθηκε αρχείο για Pressure-Based Data.")
                return
            self.df_tab2 = pd.read_csv(file_path)
        # Δεδομένα για Tab 2:
        # Πίεση: στήλη 11 (index 10)
        # Θερμοκρασία: στήλη 12 (index 11)
        if self.df_tab2.shape[1] < 12:
            QMessageBox.critical(self, "Σφάλμα", "Το αρχείο Pressure-Based δεν περιέχει 12 στήλες.")
            return
        self.pressure_tab2 = self.df_tab2.iloc[:, 10]
        self.temperature_tab2 = self.df_tab2.iloc[:, 11]

    def compute_altitude_from_pressure(self, P0, T0):
        T0 += 273.15
        L = 0.0065
        R = 8.31432
        g = 9.80665
        M = 0.0289644
        altitude = (T0 / L) * (1 - (self.pressure_tab2 / P0) ** ((R * L) / (g * M)))
        return altitude

    def plot_tab2_raw(self):
        try:
            P0 = float(self.tab2_edit_P0.text())
            T0 = float(self.tab2_edit_T0.text())
        except ValueError:
            QMessageBox.warning(self, "Προειδοποίηση", "Παρακαλώ εισάγετε έγκυρες τιμές για P₀ και T₀.")
            return
        alt_from_pressure = self.compute_altitude_from_pressure(P0, T0)
        self.tab2_plot.clear()
        self.tab2_plot.plot(alt_from_pressure, self.temperature_tab2, pen='r', symbol='o', symbolSize=5, symbolBrush='b')
        self.tab2_plot.setLabel("left", "Θερμοκρασία (°C)")
        self.tab2_plot.setLabel("bottom", "Υψόμετρο (m)")
        self.tab2_plot.setTitle("Pressure-Based Altitude vs Temperature (Raw)")

    def plot_tab2_rolling(self):
        try:
            P0 = float(self.tab2_edit_P0.text())
            T0 = float(self.tab2_edit_T0.text())
        except ValueError:
            QMessageBox.warning(self, "Προειδοποίηση", "Παρακαλώ εισάγετε έγκυρες τιμές για P₀ και T₀.")
            return
        alt_from_pressure = self.compute_altitude_from_pressure(P0, T0)
        alt_roll = alt_from_pressure.rolling(window=11, center=True).mean()
        temp_roll = self.temperature_tab2.rolling(window=11, center=True).mean()
        self.tab2_plot.clear()
        self.tab2_plot.plot(alt_roll, temp_roll, pen='b', symbol='o', symbolSize=5, symbolBrush='b')
        self.tab2_plot.setLabel("left", "Θερμοκρασία (°C)")
        self.tab2_plot.setLabel("bottom", "Υψόμετρο (m)")
        self.tab2_plot.setTitle("Pressure-Based Altitude vs Temperature (Rolling Average)")

    def plot_tab2_savgol(self):
        try:
            P0 = float(self.tab2_edit_P0.text())
            T0 = float(self.tab2_edit_T0.text())
        except ValueError:
            QMessageBox.warning(self, "Προειδοποίηση", "Παρακαλώ εισάγετε έγκυρες τιμές για P₀ και T₀.")
            return
        alt_from_pressure = self.compute_altitude_from_pressure(P0, T0)
        alt_savgol = savgol_filter(alt_from_pressure, window_length=11, polyorder=2)
        temp_savgol = savgol_filter(self.temperature_tab2, window_length=11, polyorder=2)
        self.tab2_plot.clear()
        self.tab2_plot.plot(alt_savgol, temp_savgol, pen='g', symbol='o', symbolSize=5, symbolBrush='b')
        self.tab2_plot.setLabel("left", "Θερμοκρασία (°C)")
        self.tab2_plot.setLabel("bottom", "Υψόμετρο (m)")
        self.tab2_plot.setTitle("Pressure-Based Altitude vs Temperature (Savitzky-Golay)")

    def save_plot(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Αποθήκευση Γραφήματος", "diagram.png", "PNG Files (*.png);;All Files (*)")
        if file_path:
            current_index = self.tabs.currentIndex()
            if current_index == 0:
                exporter = ImageExporter(self.tab1_plot.plotItem)
            else:
                exporter = ImageExporter(self.tab2_plot.plotItem)
            exporter.export(file_path)
            QMessageBox.information(self, "Επιτυχία", f"Το γράφημα αποθηκεύτηκε ως {file_path}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = FourthStepWindow()
    window.show()
    sys.exit(app.exec())
